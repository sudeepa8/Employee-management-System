package com.usersdemo.usersdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
